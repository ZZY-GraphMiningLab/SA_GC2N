# SA-GC²N: Sparse Attentive Graph Capsule Convolutional Network (PyTorch)

This repository provides the official PyTorch implementation of **SA-GC²N** (Sparse Attentive
Graph Capsule Convolutional Network), a lightweight model for shared-account sequential
recommendation, from the paper:

> **Efficient yet Adaptive: Sparse Attentive Graph Capsule Convolutional Network for
> Shared-Account Sequential Recommendation**
> Jinyu Zhang, Zhongying Zhao, Chao Li
> *ACM Transactions on Information Systems (under review)*

If you find this code useful in your research, please consider citing our paper once it is
formally published.

SA-GC²N couples a lightweight graph capsule convolutional encoder with Adaptive Capsule
Selection (ACS) and a sparse attentive sequence decoder (NSA). The model is evaluated with
`Recall@{5,20}` and `MRR@{5,20}` under the full-rank protocol on four real-world
shared-account datasets.

## Repository structure

```
SAGC2N_Torch.py   single-file implementation (configuration presets, unified split builder,
                  data loading, sequential graph construction, graph capsule encoder, ACS,
                  Merged Dynamic Routing, NSA decoder, training, validation-based model
                  selection and one-shot test evaluation)
Data/             four benchmark datasets (raw released files)
check_points/     best checkpoints are written here automatically
logs/             every run writes its own log file here automatically
```

## Requirements

- Python >= 3.8, PyTorch >= 2.0 (CPU or CUDA build), NumPy, SciPy, tqdm

```bash
pip install torch numpy scipy tqdm
```

## Data and the unified sequence-level split

The four datasets are included in their original released form:

```
Data/
├── Hamazon_B/  train_data.txt  test_data.txt  user_dict.txt  item_dict.txt
├── Hamazon_M/
├── Hvideo_E/
└── Hvideo_V/
```

- `train_data.txt / test_data.txt`: `account_id \t item_id \t item_id \t ...`
  (the last item of a record is the ground-truth target of that record)
- `user_dict.txt / item_dict.txt`: `index \t orig_id \t [count]`

On the first run the code automatically derives the **unified sequence-level split** used in
the paper from the two raw files of each dataset: exact duplicates are collapsed, records too
short to yield a prediction query are excluded, related records (one sequence being a
complete prefix of another) are collected into groups so that no group spans two partitions,
and for every account with `G >= 3` groups the first `h = max(1, floor(G/10))` groups form the
test partition, the next `h` groups form the validation partition and the remaining groups
form the training partition. The derived partition is deterministic (it does not depend on
any random seed) and is cached as `Data/{dataset}/split_{train,valid,test}_data.txt`.

If you want to use your own fixed partition instead, place files with the same three names
and the same row format into the dataset directory; they will be used as-is.

## Quickstart

```bash
# Build (and inspect) the three-way split only, then exit
python SAGC2N_Torch.py --dataset Hvideo_E --prepare_only

# Train and evaluate with the paper configuration (seed 17 by default)
python SAGC2N_Torch.py --dataset Hvideo_E

# Fast sanity check on small subsets
python SAGC2N_Torch.py --dataset Hvideo_E --fast_running --fast_ratio 0.03 \
    --num_epochs 3 --eval_verbose 1

# Reproduce the five-run protocol of the paper (mean / sample SD)
for s in 17 29 43 71 101; do
  python SAGC2N_Torch.py --dataset Hvideo_E --seed $s
done
```

Every run automatically writes a timestamped log file to
`logs/{dataset}/{dataset}_seed{seed}_{timestamp}.log` and saves its best checkpoint to
`check_points/{dataset}_seed{seed}_best.pth`.

## Training and evaluation protocol

- Each query uses the visible prefix (all items except the last) as input and the last item
  as the target; the ranking is over the full catalog, including previously visited items.
- Validation `Recall@5` is checked every 10 epochs. The earliest checkpoint attaining a
  **strict** improvement is retained, and training stops after three checks without
  improvement or at 200 epochs. The selected checkpoint is evaluated on the test set exactly
  once at the end of the run.
- Metrics average over every evaluation query, including the final incomplete batch. Tied
  scores are ordered by ascending item id.
- The sequential graph is built from the training records (including their supervised
  targets) and stays frozen during validation and testing.
- Gumbel noise is enabled during training and disabled at inference, with the routing
  temperature fixed at 0.3 in both phases.

## Per-dataset configuration

| parameter | Hvideo_E | Hvideo_V | Hamazon_M | Hamazon_B |
|---|---|---|---|---|
| embedding size `d` | 16 | 16 | 16 | 16 |
| capsule size | 16 | 16 | 16 | 16 |
| capsule transformations `L` | 3 | 3 | 3 | 3 |
| candidate capsules `C` | 5 | 5 | 10 | 10 |
| block size `b` | 4 | 4 | 1 | 1 |
| requested blocks `K` | 2 | 2 | 8 | 8 |
| window size `w` | 10 | 12 | 6 | 6 |
| learning rate | 0.01 | 0.004 | 0.01 | 0.01 |
| routing temperature | 0.3 | 0.3 | 0.3 | 0.3 |
| dropout rate | 0.1 | 0.1 | 0.1 | 0.1 |
| batch size | 256 | 256 | 256 | 256 |
| epochs (cap) | 200 | 200 | 200 | 200 |
| eval interval | 10 | 10 | 10 | 10 |
| early-stop patience | 3 | 3 | 3 | 3 |

The optimizer is Adam with the dataset-specific learning rate above, and all weights are
initialized with Xavier initialization. No active-count penalty is applied.

## Command-line arguments

| argument | default | description |
|---|---|---|
| `--dataset` | `Hvideo_E` | one of `Hamazon_B / Hamazon_M / Hvideo_E / Hvideo_V` |
| `--data_root` | `Data/{dataset}` | override the dataset directory |
| `--seed` | `17` | random seed (the paper reports seeds 17, 29, 43, 71, 101) |
| `--num_epochs` | 200 | override the epoch cap |
| `--patience` | 3 | early-stopping patience in evaluations (0 disables) |
| `--eval_verbose` | 10 | evaluate on the validation split every N epochs |
| `--max_capsules` | preset | override the number of candidate capsules `C` |
| `--ablation` | `full` | model variant, see below |
| `--fast_running` | off | run on subsets of every split |
| `--fast_ratio` | 0.2 | fraction used by `--fast_running` |
| `--prepare_only` | off | only build the split files, then exit |
| `--gpu_index` | `0` | CUDA device index (auto-fallback to CPU) |

Ablation variants (`--ablation`): `full` (the complete model), `wo_acs` (uniform capsule
gates), `wrong_caps` (single fixed capsule), `dense` (dense attention decoder), `wo_compress`,
`wo_select` and `wo_sliding` (NSA branch removals).

We encourage reviewers to examine the code thoroughly and to report any issue that prevents
reproducing the results of the paper.
