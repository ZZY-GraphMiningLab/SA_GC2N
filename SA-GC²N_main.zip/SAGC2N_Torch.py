

import argparse
import logging
import os
import random
import warnings
from time import time, strftime

import numpy as np
import scipy.sparse as sp
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm

np.seterr(all='ignore')
warnings.filterwarnings('ignore', message='.*Sparse invariant checks.*')


DATASET_PRESETS = {
    'Hamazon_B': dict(embedding_size=16, capsule_size=16, num_layers=3,
                      max_capsules=10, block_size=1, n_select_blocks=8,
                      window_size=6, learning_rate=0.01),
    'Hamazon_M': dict(embedding_size=16, capsule_size=16, num_layers=3,
                      max_capsules=10, block_size=1, n_select_blocks=8,
                      window_size=6, learning_rate=0.01),
    'Hvideo_E':  dict(embedding_size=16, capsule_size=16, num_layers=3,
                      max_capsules=5, block_size=4, n_select_blocks=2,
                      window_size=10, learning_rate=0.01),
    'Hvideo_V':  dict(embedding_size=16, capsule_size=16, num_layers=3,
                      max_capsules=5, block_size=4, n_select_blocks=2,
                      window_size=12, learning_rate=0.004),
}


class ParamConf:
    

    def __init__(self, dataset='Hvideo_E'):
        preset = DATASET_PRESETS[dataset]

        
        self.embedding_size = preset['embedding_size']
        self.capsule_size = preset['capsule_size']
        self.num_layers = preset['num_layers']
        self.num_folded = self.embedding_size  

        
        self.max_capsules = preset['max_capsules']
        self.temperature = 0.3
        self.sparsity_lambda = 0.0

        self.block_size = preset['block_size']
        self.n_select_blocks = preset['n_select_blocks']
        self.window_size = preset['window_size']

        
        self.learning_rate = preset['learning_rate']
        self.dropout_rate = 0.1
        self.dropout_enabled = True
        self.batch_size = 256
        self.num_epochs = 200
        self.patience = 3
        self.eval_verbose = 10
        self.fast_running = False
        self.fast_ratio = 0.2
        self.seed = 17

        self.ablation = 'full'

        self.st_mode = 'fixed'

        self.slot_mode = 'aligned'

        self.dataset = dataset
        self.data_root = os.path.join('Data', self.dataset)
        self.raw_train_path = os.path.join(self.data_root, 'train_data.txt')
        self.raw_test_path = os.path.join(self.data_root, 'test_data.txt')
        self.train_path = os.path.join(self.data_root, 'split_train_data.txt')
        self.valid_path = os.path.join(self.data_root, 'split_valid_data.txt')
        self.test_path = os.path.join(self.data_root, 'split_test_data.txt')
        self.item_path = os.path.join(self.data_root, 'item_dict.txt')
        self.user_path = os.path.join(self.data_root, 'user_dict.txt')
        self.check_points = os.path.join('check_points', self.dataset)
        self.logs = os.path.join('logs', self.dataset)

        
        self.gpu_index = '0'
        self.device = torch.device('cuda:' + self.gpu_index if torch.cuda.is_available() else 'cpu')


def parse_args():
    parser = argparse.ArgumentParser(description='SA-GC^2N (PyTorch)')
    parser.add_argument('--dataset', type=str, default='Hvideo_E',
                        choices=list(DATASET_PRESETS.keys()),
                        help='One of Hamazon_B / Hamazon_M / Hvideo_E / Hvideo_V')
    parser.add_argument('--data_root', type=str, default=None,
                        help='Override the dataset directory (defaults to Data/{dataset})')
    parser.add_argument('--seed', type=int, default=17,
                        help='Random seed (the paper uses 17, 29, 43, 71 and 101)')
    parser.add_argument('--num_epochs', type=int, default=None, help='Override training epochs')
    parser.add_argument('--patience', type=int, default=None,
                        help='Early stopping patience in evaluations: stop after N consecutive '
                             'evaluations without a strict Recall@5 improvement (0 = disable)')
    parser.add_argument('--eval_verbose', type=int, default=None,
                        help='Evaluate on the validation split every N epochs (default 10)')
    parser.add_argument('--max_capsules', type=int, default=None,
                        help='Override the number of candidate capsules C')
    parser.add_argument('--ablation', type=str, default='full',
                        choices=['full', 'wo_acs', 'wrong_caps', 'dense',
                                 'wo_compress', 'wo_select', 'wo_sliding'],
                        help='Model variant (full = SA-GC^2N)')
    parser.add_argument('--fast_running', action='store_true', help='Run on a subset for a quick check')
    parser.add_argument('--fast_ratio', type=float, default=None,
                        help='Fraction of each split used with --fast_running (default 0.2)')
    parser.add_argument('--prepare_only', action='store_true',
                        help='Only build the train/validation/test split files, then exit')
    parser.add_argument('--gpu_index', type=str, default='0')
    return parser.parse_args()


def load_dict(dict_path):
    
    dict_output = {}
    with open(dict_path, 'r') as file_object:
        elements = file_object.readlines()
    for dict_element in elements:
        dict_element = dict_element.strip().split('\t')
        dict_output[dict_element[1]] = int(dict_element[0])
    return dict_output


def prepare_split(raw_train_path, raw_test_path, train_path, valid_path, test_path):
    rows = []
    first_index = {}
    index = 0
    for path in [raw_train_path, raw_test_path]:
        with open(path, 'r') as file_object:
            for line in file_object:
                elements = line.strip().split('\t')
                if not elements or elements[0] == '':
                    continue
                record = (elements[0], tuple(elements[1:]))
                if record not in first_index:
                    first_index[record] = index
                index += 1
                rows.append(record)

    unique_rows = list(dict.fromkeys(rows))
    duplicates = len(rows) - len(unique_rows)

    by_account = {}
    excluded = 0
    for account, sequence in unique_rows:
        if len(sequence) < 2:
            excluded += 1
            continue
        by_account.setdefault(account, []).append(sequence)

    train_rows, valid_rows, test_rows = [], [], []
    train_items = set()
    test_targets = 0
    unseen_targets = 0
    total_groups = 0
    train_only_accounts = 0
    test_accounts = 0

    for account in sorted(by_account):
        sequences = by_account[account]
        parent = list(range(len(sequences)))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        for i in range(len(sequences)):
            for j in range(i + 1, len(sequences)):
                a, b = sequences[i], sequences[j]
                if len(a) > len(b):
                    a, b = b, a
                if b[:len(a)] == a:
                    ra, rb = find(i), find(j)
                    if ra != rb:
                        parent[rb] = ra

        components = {}
        for i, sequence in enumerate(sequences):
            components.setdefault(find(i), []).append(sequence)
        groups = list(components.values())
        total_groups += len(groups)
        groups.sort(key=lambda g: first_index[(account, min(g, key=lambda s: (len(s), s)))])

        num_groups = len(groups)
        h = max(1, num_groups // 10) if num_groups >= 3 else 0
        if num_groups >= 3:
            test_accounts += 1
        else:
            train_only_accounts += 1
        for position, group in enumerate(groups):
            if num_groups < 3 or position >= 2 * h:
                partition = train_rows
            elif position < h:
                partition = test_rows
            else:
                partition = valid_rows
            for sequence in group:
                partition.append((account, sequence))
                if partition is train_rows:
                    train_items.update(sequence)

    for account, sequence in test_rows:
        test_targets += 1
        if sequence[-1] not in train_items:
            unseen_targets += 1

    with open(train_path, 'w') as file_object:
        for account, sequence in train_rows:
            file_object.write(account + '\t' + '\t'.join(sequence) + '\n')
    with open(valid_path, 'w') as file_object:
        for account, sequence in valid_rows:
            file_object.write(account + '\t' + '\t'.join(sequence) + '\n')
    with open(test_path, 'w') as file_object:
        for account, sequence in test_rows:
            file_object.write(account + '\t' + '\t'.join(sequence) + '\n')

    stats = {'source rows': len(rows), 'duplicates collapsed': duplicates,
             'records excluded': excluded, 'groups': total_groups,
             'train': len(train_rows), 'validation': len(valid_rows),
             'test': len(test_rows), 'train-only accounts': train_only_accounts,
             'test accounts': test_accounts, 'unseen test targets': unseen_targets}
    return stats


def config_input(data_path, item_dict, user_dict):
    data = []
    with open(data_path, 'r') as file:
        for line in file:
            elements = line.strip().split('\t')

            user_sequence, positions = [], []
            for index, element in enumerate(elements[1:-1], start=0):
                user_sequence.append(item_dict[element])
                positions.append(index)
            user_sequence.append(item_dict[elements[-1]])
            user_sequence.insert(0, user_dict[elements[0]])

            sequence_length = len(user_sequence) - 2
            target_item_id = item_dict[elements[-1]]
            data.append([user_sequence, positions, sequence_length, target_item_id])
    return data


def matrix2list(matrix):
    
    return [list(pair) for pair in dict.fromkeys(map(tuple, matrix))]


def trans_matrix_form(data):
    
    matrix_i2i, matrix_i2u, matrix_u2i, matrix_u2u = [], [], [], []

    for record in data:
        sequence = record[0]
        user = int(sequence[0])
        items = [int(i) for i in sequence[1:]]

        for item_index in range(len(items) - 1):
            item_temp = items[item_index]
            next_item = items[item_index + 1]
            matrix_i2i.append([item_temp, item_temp])
            matrix_i2i.append([item_temp, next_item])

        for item in items:
            matrix_u2i.append([user, item])
            matrix_i2u.append([item, user])

        matrix_u2u.append([user, user])

    matrix_i2i = np.array(matrix2list(matrix_i2i)).reshape(-1, 2)
    matrix_i2u = np.array(matrix2list(matrix_i2u)).reshape(-1, 2)
    matrix_u2i = np.array(matrix2list(matrix_u2i)).reshape(-1, 2)
    matrix_u2u = np.array(matrix2list(matrix_u2u)).reshape(-1, 2)

    return [matrix_i2i, matrix_i2u, matrix_u2i, matrix_u2u]


def matrix2inverse(array_in, row_index, col_index, matrix_dimension):
    
    matrix_rows = [row + row_index for row, _ in array_in]
    matrix_columns = [col + col_index for _, col in array_in]
    matrix_value = [1.] * len(matrix_rows)
    return sp.coo_matrix((matrix_value, (matrix_rows, matrix_columns)),
                         shape=(matrix_dimension, matrix_dimension))


def graph_construction(matrices, item_dict, user_dict):
    
    item_size = len(item_dict)
    user_size = len(user_dict)
    num_all = item_size + user_size

    matrix_i2i = matrix2inverse(matrices[0], row_index=0, col_index=0, matrix_dimension=num_all)
    matrix_i2u = matrix2inverse(matrices[1], row_index=0, col_index=item_size, matrix_dimension=num_all)
    matrix_u2i = matrix2inverse(matrices[2], row_index=item_size, col_index=0, matrix_dimension=num_all)
    matrix_u2u = matrix2inverse(matrices[3], row_index=item_size, col_index=item_size, matrix_dimension=num_all)

    
    laplace_list = (matrix_i2i + matrix_i2u + matrix_u2i + matrix_u2u).tocoo()

    indices = torch.from_numpy(np.vstack([laplace_list.row, laplace_list.col])).long()
    values = torch.from_numpy(laplace_list.data.astype(np.float32))
    graph = torch.sparse_coo_tensor(indices, values, torch.Size(laplace_list.shape)).coalesce()
    return graph


def load_batches(batch, padding_num):
    user, sequence, position, length, target = [], [], [], [], []
    max_length = max([data_index[2] for data_index in batch])

    for data_index in batch:
        user.append(data_index[0][0])
        sequence.append(data_index[0][1:-1] + [padding_num] * (max_length - data_index[2]))
        position.append(data_index[1][:] + [padding_num] * (max_length - data_index[2]))
        length.append(data_index[2])
        target.append(data_index[3])

    return (np.array(user), np.array(sequence), np.array(position),
            np.array(length).reshape(-1, 1), np.array(target))


def generate_batches(input_data, batch_size, padding_num, is_train):
    user_all, sequence_all, position_all, length_all, target_all = [], [], [], [], []
    num_batches = int(np.ceil(len(input_data) / batch_size))

    if is_train:
        np.random.shuffle(input_data)

    for batch_index in range(num_batches):
        start_index = batch_index * batch_size
        batch = input_data[start_index:start_index + batch_size]
        user, sequence, position, length, target = load_batches(batch, padding_num)
        user_all.append(user)
        sequence_all.append(sequence)
        position_all.append(position)
        length_all.append(length)
        target_all.append(target)

    return user_all, sequence_all, position_all, length_all, target_all, num_batches


def gelu(x):
    
    return 0.5 * x * (1.0 + torch.tanh(np.sqrt(2.0 / np.pi) * (x + 0.044715 * torch.pow(x, 3))))


def squash(s, epsilon=1e-7):
    
    squared_norm = (s * s).sum(dim=-1, keepdim=True)
    safe_norm = torch.sqrt(squared_norm + epsilon)
    squash_factor = squared_norm / (1.0 + squared_norm)
    unit_vector = s / safe_norm
    return squash_factor * unit_vector


def dynamic_routing(b_ij, inputs, routing_iterations):
    
    assert inputs.shape[1] == b_ij.shape[1]
    v_j = None
    for iteration in range(routing_iterations):
        c_ij = torch.softmax(b_ij, dim=2)
        s_j = (c_ij * inputs).sum(dim=1, keepdim=True)
        v_j = squash(s_j)
        if iteration < routing_iterations - 1:
            b_ij = b_ij + (inputs * v_j).sum(dim=0, keepdim=True)
    return v_j


class ManualLayerNorm(nn.Module):
    

    def __init__(self, normalized_shape, epsilon):
        super().__init__()
        self.epsilon = epsilon
        self.gamma = nn.Parameter(torch.ones(normalized_shape))
        self.beta = nn.Parameter(torch.zeros(normalized_shape))

    def forward(self, x):
        mean = x.mean(dim=-1, keepdim=True)
        var = ((x - mean) ** 2).mean(dim=-1, keepdim=True)
        return self.gamma * (x - mean) / torch.sqrt(var + self.epsilon) + self.beta


class LinearAttention(nn.Module):
    

    def __init__(self, in_dim, out_dim, dropout_rate, dropout_enabled):
        super().__init__()
        self.dense = nn.Linear(in_dim, out_dim)
        self.dropout = nn.Dropout(dropout_rate) if dropout_enabled else None

    def forward(self, x):
        key = x.transpose(0, 1)                    
        attention_maps = torch.matmul(key, x)      
        normed_ebd = torch.softmax(attention_maps, dim=1)
        scored_ebd = torch.matmul(x, normed_ebd)   
        if self.dropout is not None:
            scored_ebd = self.dropout(scored_ebd)
        return self.dense(scored_ebd)


class GCNLayer(nn.Module):
    

    def __init__(self, ebd_size, cap_size, max_capsules, temperature, sparsity_lambda,
                 dropout_rate, dropout_enabled, ablation='full', st_mode='faithful'):
        super().__init__()
        self.max_capsules = max_capsules
        self.temperature = temperature
        self.sparsity_lambda = sparsity_lambda
        self.ablation = ablation
        self.st_mode = st_mode

        
        self.item_conv = nn.Linear(ebd_size, cap_size)
        self.item_att = LinearAttention(ebd_size, cap_size, dropout_rate, dropout_enabled)
        self.item_norm = ManualLayerNorm((1, cap_size), epsilon=1e-12)

        
        self.user_conv = nn.Linear(ebd_size, max_capsules * cap_size)

        
        self.selector_gate = nn.Linear(max_capsules * cap_size, max_capsules)

    def att_conv_item(self, item_ebd):
        n = item_ebd.shape[0]
        capsules_conv = self.item_conv(item_ebd).unsqueeze(1)          
        capsules_att = self.item_att(item_ebd).unsqueeze(1)            
        capsules = capsules_att + capsules_conv                        
        capsules = self.item_norm(capsules)                            
        capsules = squash(capsules.reshape(n, 1, -1))                  
        return capsules

    def conv_user(self, user_ebd):
        n = user_ebd.shape[0]
        capsules = self.user_conv(user_ebd).reshape(n, self.max_capsules, -1)
        return squash(capsules)                                        

    def adaptive_selection(self, primary_users):
        
        n, c, d = primary_users.shape

        if self.ablation == 'wo_acs':
            selected_gates = torch.ones(n, c, dtype=primary_users.dtype,
                                        device=primary_users.device)
            self._gates_cache = selected_gates.detach()
            weighted_capsules = selected_gates.unsqueeze(-1) * primary_users
            return weighted_capsules, torch.zeros(
                (), dtype=primary_users.dtype, device=primary_users.device)

        if self.ablation == 'wrong_caps':
            
            
            cap = int(getattr(self, 'forced_capsule_id', 0))
            selected_gates = torch.zeros(n, c, dtype=primary_users.dtype,
                                         device=primary_users.device)
            selected_gates[:, cap] = 1.0
            self._gates_cache = selected_gates.detach()
            weighted_capsules = selected_gates.unsqueeze(-1) * primary_users
            return weighted_capsules, torch.zeros(
                (), dtype=primary_users.dtype, device=primary_users.device)

        logits = self.selector_gate(primary_users.reshape(n, c * d))   

        if self.ablation == 'dense':
            gates = torch.softmax(logits, dim=-1)
            self._gates_cache = gates.detach()
            weighted_capsules = gates.unsqueeze(-1) * primary_users    
            return weighted_capsules, torch.zeros(
                (), dtype=primary_users.dtype, device=primary_users.device)

        if self.training:
            uniform = torch.rand_like(logits)
            gumbel = -torch.log(-torch.log(uniform + 1e-20) + 1e-20)
            gates = torch.softmax((logits + gumbel) / self.temperature, dim=-1)
        else:
            
            
            gates = torch.softmax(logits / self.temperature, dim=-1)

        threshold = (gates >= 1.0 / self.max_capsules).to(primary_users.dtype)
        self._gates_cache = gates.detach()      

        if getattr(self, 'st_mode', 'fixed') == 'fixed':
            
            
            selected_gates = threshold.detach() + gates - gates.detach()
            activation_rate = gates.mean()          
        else:
            
            
            selected_gates = threshold + (gates - threshold).detach()
            activation_rate = selected_gates.mean().detach()

        
        sparse_loss = self.sparsity_lambda * torch.log(activation_rate + 1e-5)

        
        weighted_capsules = selected_gates.unsqueeze(-1) * primary_users  
        return weighted_capsules, sparse_loss


class SAGC2N(nn.Module):
    

    def __init__(self, num_items, num_users, laplace_graph, param):
        super().__init__()
        self.num_items = num_items
        self.num_users = num_users
        self.param = param

        self.ebd_size = param.embedding_size
        self.cap_size = param.capsule_size
        self.max_capsules = param.max_capsules
        self.num_layers = param.num_layers
        self.block_size = param.block_size
        self.n_select_blocks = param.n_select_blocks
        self.window_size = param.window_size
        self.dropout_enabled = param.dropout_enabled
        self.dropout = nn.Dropout(param.dropout_rate) if param.dropout_enabled else None

        self.register_buffer('laplace_graph', laplace_graph)

        self._init_weights()

        
        self.ablation = getattr(param, 'ablation', 'full')
        self.slot_mode = getattr(param, 'slot_mode', 'faithful')

        
        self.nsa_branches = ['compress', 'select', 'window']
        if self.ablation == 'wo_compress':
            self.nsa_branches.remove('compress')
        elif self.ablation == 'wo_select':
            self.nsa_branches.remove('select')
        elif self.ablation == 'wo_sliding':
            self.nsa_branches.remove('window')

        
        self.gcn_layers = nn.ModuleList([
            GCNLayer(self.ebd_size, self.cap_size, self.max_capsules,
                     param.temperature, param.sparsity_lambda,
                     param.dropout_rate, param.dropout_enabled,
                     ablation=self.ablation,
                     st_mode=getattr(param, 'st_mode', 'faithful'))
            for _ in range(self.num_layers)
        ])

        
        self.compress_dense = nn.Linear(self.block_size * self.ebd_size, self.ebd_size)
        self.window_dense = nn.Linear(self.ebd_size, self.ebd_size)
        self.nsa_gate_dense = nn.Linear(len(self.nsa_branches) * self.ebd_size,
                                        len(self.nsa_branches))
        self.final_norm = ManualLayerNorm(self.ebd_size, epsilon=1e-5)

        
        self.pred_dense = nn.Linear(2 * self.ebd_size, self.num_items)

        self._sparse_losses = []

        self._xavier_init()

    def _xavier_init(self):
        
        nn.init.xavier_uniform_(self.item_embedding)
        nn.init.xavier_uniform_(self.user_embedding)
        nn.init.xavier_uniform_(self.padding_embedding)
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                nn.init.zeros_(module.bias)
        
        
        nn.init.xavier_normal_(self.pred_dense.weight)
        nn.init.zeros_(self.pred_dense.bias)

    def forward(self, user, sequence):
        self._sparse_losses = []  
        graph_ebd_items, graph_ebd_users = self.graph_encoder()
        prediction, sparse_losses = self.output_prediction(graph_ebd_items, graph_ebd_users,
                                                           user, sequence)
        return prediction, sparse_losses

    def graph_encoder(self):
        
        item_ebd = self.item_embedding
        user_ebd = self.user_embedding
        ego_embeddings = torch.cat([item_ebd, user_ebd], dim=0)      

        
        propagated = torch.sparse.mm(self.laplace_graph, ego_embeddings)
        temp_item_ebd, temp_user_ebd = torch.split(
            propagated, [self.num_items, self.num_users], dim=0)

        all_embeddings = [ego_embeddings]
        for layer in self.gcn_layers:
            
            primary_items = layer.att_conv_item(temp_item_ebd)       
            
            primary_users = layer.conv_user(temp_user_ebd)           
            selected_capsules, sparse_loss = layer.adaptive_selection(primary_users)
            self._sparse_losses.append(sparse_loss)

            
            b_ij = torch.zeros(selected_capsules.shape[0], self.max_capsules, self.cap_size,
                               device=selected_capsules.device)
            digit_caps = dynamic_routing(b_ij, selected_capsules, routing_iterations=3)  

            
            layer._user_repr_cache = digit_caps.detach().squeeze(1)
            layer._item_repr_cache = primary_items.detach().squeeze(1)

            if self.slot_mode == 'aligned':
                
                
                node_embeddings = torch.cat([primary_items, digit_caps], dim=0)
            else:
                
                
                node_embeddings = torch.cat([digit_caps, primary_items], dim=0)
            node_embeddings = node_embeddings.sum(dim=1)                     
            all_embeddings.append(node_embeddings)

        all_embeddings = torch.stack(all_embeddings, dim=1)
        all_embeddings = all_embeddings.mean(dim=1)

        graph_ebd_items, graph_ebd_users = torch.split(
            all_embeddings, [self.num_items, self.num_users], dim=0)
        return graph_ebd_items, graph_ebd_users

    def native_sparse_attention_network(self, seq_ebd):
        
        block_size = self.block_size
        n_select_blocks = self.n_select_blocks
        window_size = self.window_size

        batch_size, seq_len, embed_size = seq_ebd.shape

        
        pad_len = (-seq_len) % block_size
        padded_seq = F.pad(seq_ebd, (0, 0, 0, pad_len))

        
        num_blocks = (seq_len + pad_len) // block_size
        blocks = padded_seq.reshape(batch_size, num_blocks, block_size, embed_size)
        compressed = gelu(self.compress_dense(
            blocks.reshape(batch_size, num_blocks, block_size * embed_size)))  

        
        last_token = seq_ebd[:, -1:, :]                                        
        attention_scores = torch.matmul(last_token, compressed.transpose(1, 2))  
        k = min(n_select_blocks, num_blocks)
        top_values, top_indices = torch.topk(attention_scores, k, dim=-1)      
        gather_idx = top_indices.squeeze(1).unsqueeze(-1).expand(-1, -1, embed_size)
        selected = torch.gather(compressed, 1, gather_idx)                     

        
        if seq_len >= window_size:
            window = seq_ebd[:, -window_size:, :]
        else:
            window = F.pad(seq_ebd, (0, 0, window_size - seq_len, 0))
        window = gelu(self.window_dense(window))                               

        
        feats = {}
        feats['compress'] = compressed.mean(dim=1)
        feats['select'] = selected.mean(dim=1)
        feats['window'] = window.mean(dim=1)

        branch_feats = [feats[name] for name in self.nsa_branches]
        if len(self.nsa_branches) == 1:
            refined = branch_feats[0]
        else:
            gate_input = torch.cat(branch_feats, dim=-1)
            gates = torch.softmax(self.nsa_gate_dense(gate_input), dim=-1)     
            refined = sum(gates[:, i:i + 1] * feat
                          for i, feat in enumerate(branch_feats))

        
        refined = self.final_norm(refined)
        return refined

    def output_prediction(self, graph_seq_ebd, graph_ebd_users, user, sequence):
        
        seq_table = torch.cat([graph_seq_ebd, self.padding_embedding], dim=0)  
        user_ebd = F.embedding(user, graph_ebd_users)                          
        seq_ebd = F.embedding(sequence, seq_table)                             

        
        refined_seq_ebd = self.native_sparse_attention_network(seq_ebd)        

        concat_ebd = torch.cat([user_ebd, refined_seq_ebd], dim=-1)
        if self.dropout is not None:
            concat_ebd = self.dropout(concat_ebd)
        prediction = self.pred_dense(concat_ebd)                               

        sparse_losses = torch.stack(self._sparse_losses)
        return prediction, sparse_losses

    def _init_weights(self):
        self.item_embedding = nn.Parameter(torch.empty(self.num_items, self.ebd_size))
        self.user_embedding = nn.Parameter(torch.empty(self.num_users, self.ebd_size))
        
        self.padding_embedding = nn.Parameter(torch.empty(1, self.ebd_size))


def cal_loss_mean(target, prediction):
    
    return F.cross_entropy(prediction, target)


def train_module(module, batches_train, optimizer, param):
    users, sequences, positions, lengths, targets, batch_num = batches_train

    shuffled_indices = np.random.permutation(batch_num)
    total_loss = 0.0

    module.train()
    progress = tqdm(range(batch_num), desc='Training', leave=False)
    for index in progress:
        user = torch.from_numpy(users[index]).long().to(param.device)
        sequence = torch.from_numpy(sequences[index]).long().to(param.device)
        target = torch.from_numpy(targets[index]).long().to(param.device)

        optimizer.zero_grad()
        prediction, sparse_losses = module(user, sequence)
        
        
        batch_loss = cal_loss_mean(target, prediction) + sparse_losses.sum()
        batch_loss.backward()

        
        torch.nn.utils.clip_grad_value_(module.parameters(), 5.0)
        optimizer.step()

        total_loss += batch_loss.item()
        progress.set_postfix(loss=f'{batch_loss.item():.4f}')

    avg_loss = total_loss / batch_num
    return avg_loss


def model_evaluation(module, batches_eval, eval_length, param):
    user_all, sequence_all, position_all, length_all, target_all, eval_batch_num = (
        batches_eval[0], batches_eval[1], batches_eval[2],
        batches_eval[3], batches_eval[4], batches_eval[5])
    rc_5, rc_20, mrr_5, mrr_20 = 0.0, 0.0, 0.0, 0.0

    module.eval()
    with torch.no_grad():
        for batch_index in range(eval_batch_num):
            user = torch.from_numpy(user_all[batch_index]).long().to(param.device)
            sequence = torch.from_numpy(sequence_all[batch_index]).long().to(param.device)
            prediction = module(user, sequence)[0].cpu().numpy()
            recall, mrr = eval_metrics(prediction, target_all[batch_index], [5, 20])
            rc_5 += recall[0]
            rc_20 += recall[1]
            mrr_5 += mrr[0]
            mrr_20 += mrr[1]

    return [rc_5 / eval_length, rc_20 / eval_length,
            mrr_5 / eval_length, mrr_20 / eval_length]


def eval_metrics(predictions, ground_truths, k_list):
    Recalls, MRRs = [], []

    sorted_indices = np.argsort(-predictions, axis=1, kind='stable')

    for k in k_list:
        Recalls.append(0)
        MRRs.append(0)

        top_k_indices = sorted_indices[:, :k]

        for current_index in range(len(ground_truths)):
            match_positions = np.argwhere(top_k_indices[current_index] == ground_truths[current_index])

            if len(match_positions) > 0:
                Recalls[-1] += 1
                MRRs[-1] += 1 / (match_positions[0][0] + 1)

    return Recalls, MRRs


def setup_logging(param):
    os.makedirs(param.logs, exist_ok=True)
    log_file = os.path.join(
        param.logs, '{}_seed{}_{}.log'.format(
            param.dataset, param.seed, strftime('%Y%m%d_%H%M%S')))
    handlers = [logging.StreamHandler(), logging.FileHandler(log_file, encoding='utf-8')]
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s - %(levelname)s - %(message)s',
                        handlers=handlers)
    return log_file


def log_eval_box(title, rc_5, rc_20, mrr_5, mrr_20):
    lines = [title,
             '   RC5 = {:.4f}    RC20 = {:.4f}'.format(rc_5, rc_20),
             '   MRR5 = {:.4f}   MRR20 = {:.4f}'.format(mrr_5, mrr_20)]
    box = '\n' + '┌' + '─' * 58 + '┐\n'
    for line in lines:
        box += '│ ' + line.ljust(56) + ' │\n'
    box += '└' + '─' * 58 + '┘'
    logging.info(box)


def main():
    args = parse_args()
    param = ParamConf(dataset=args.dataset)
    if args.data_root is not None:
        param.data_root = args.data_root
        param.raw_train_path = os.path.join(param.data_root, 'train_data.txt')
        param.raw_test_path = os.path.join(param.data_root, 'test_data.txt')
        param.train_path = os.path.join(param.data_root, 'split_train_data.txt')
        param.valid_path = os.path.join(param.data_root, 'split_valid_data.txt')
        param.test_path = os.path.join(param.data_root, 'split_test_data.txt')
        param.item_path = os.path.join(param.data_root, 'item_dict.txt')
        param.user_path = os.path.join(param.data_root, 'user_dict.txt')
    if args.num_epochs is not None:
        param.num_epochs = args.num_epochs
    if args.patience is not None:
        param.patience = args.patience
    if args.eval_verbose is not None:
        param.eval_verbose = args.eval_verbose
    if args.max_capsules is not None:
        param.max_capsules = args.max_capsules
    if args.fast_ratio is not None:
        param.fast_ratio = args.fast_ratio
    if args.fast_running:
        param.fast_running = True
    param.ablation = args.ablation
    param.seed = args.seed
    param.gpu_index = args.gpu_index
    param.device = torch.device('cuda:' + param.gpu_index if torch.cuda.is_available() else 'cpu')

    setup_logging(param)
    logging.info('Params in setup: %s', param.__dict__)
    logging.info('Device: %s', param.device)

    if os.path.exists(param.train_path) and os.path.exists(param.valid_path) \
            and os.path.exists(param.test_path):
        logging.info('Split files found, reusing the existing split.')
    else:
        logging.info('Split files not found, building the unified sequence-level split...')
        stats = prepare_split(raw_train_path=param.raw_train_path,
                              raw_test_path=param.raw_test_path,
                              train_path=param.train_path,
                              valid_path=param.valid_path,
                              test_path=param.test_path)
        for key, value in stats.items():
            logging.info('Split stat - %s: %d', key, value)

    if args.prepare_only:
        logging.info('Split prepared (--prepare_only). Exiting.')
        return

    seed = param.seed
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    item_dict = load_dict(dict_path=param.item_path)
    user_dict = load_dict(dict_path=param.user_path)
    logging.info('Dictionaries initialized. Loading data...')

    train_data = config_input(data_path=param.train_path, item_dict=item_dict, user_dict=user_dict)
    valid_data = config_input(data_path=param.valid_path, item_dict=item_dict, user_dict=user_dict)
    test_data = config_input(data_path=param.test_path, item_dict=item_dict, user_dict=user_dict)
    logging.info('Data initialized. Train: %d, Validation: %d, Test: %d',
                 len(train_data), len(valid_data), len(test_data))

    if param.fast_running:
        train_data = train_data[:int(param.fast_ratio * len(train_data))]
        valid_data = valid_data[:int(param.fast_ratio * len(valid_data))]
        test_data = test_data[:int(param.fast_ratio * len(test_data))]
        logging.info('Fast running on subsets: Train: %d, Validation: %d, Test: %d',
                     len(train_data), len(valid_data), len(test_data))

    input_matrices = trans_matrix_form(train_data)
    logging.info('Transformation completed. Generating sequential graph...')

    laplace_list = graph_construction(input_matrices, item_dict, user_dict)
    logging.info('Graph Initialized. Generating batches...')

    valid_batches = generate_batches(input_data=valid_data, batch_size=param.batch_size,
                                     padding_num=len(item_dict), is_train=False)
    test_batches = generate_batches(input_data=test_data, batch_size=param.batch_size,
                                    padding_num=len(item_dict), is_train=False)
    logging.info('Batches Initialized. Building the recommender...')

    module = SAGC2N(num_items=len(item_dict), num_users=len(user_dict),
                    laplace_graph=laplace_list, param=param).to(param.device)

    optimizer = torch.optim.Adam(module.parameters(), lr=param.learning_rate)
    logging.info('Recommender initialized. Ready for training.')

    best_score = -1
    best_epoch = -1
    evals_since_best = 0
    stop_reason = 'max_epochs'
    save_path = param.check_points + '_seed{}_best.pth'.format(seed)
    os.makedirs(os.path.dirname(param.check_points), exist_ok=True)
    time_start = time()

    for epoch in range(param.num_epochs):
        train_batches = generate_batches(input_data=train_data, batch_size=param.batch_size,
                                         padding_num=len(item_dict), is_train=True)
        train_start = time()
        loss_train = train_module(module=module, batches_train=train_batches,
                                  optimizer=optimizer, param=param)
        time_consumption = time() - train_start
        epoch_num = epoch + 1
        logging.info('Epoch {} - Training Loss: {:.5f} - Training time: {:.3f}'.format(
            epoch_num, loss_train, time_consumption))

        if epoch_num % param.eval_verbose == 0:
            eval_start = time()
            [rc_5, rc_20, mrr_5, mrr_20] = model_evaluation(
                module=module, batches_eval=valid_batches, eval_length=len(valid_data), param=param)
            eval_consumption = time() - eval_start
            log_eval_box('Validation at Epoch {:<4d}'.format(epoch_num), rc_5, rc_20, mrr_5, mrr_20)
            logging.info('Epoch: {}, Recommender evaluate time: {:.3f}'.format(
                epoch_num, eval_consumption))

            if rc_5 > best_score:
                best_score = rc_5
                best_epoch = epoch_num
                evals_since_best = 0
                torch.save({'model_state_dict': module.state_dict(),
                            'epoch': epoch_num,
                            'rc_5': rc_5}, save_path)
                logging.info('Recommender performs better, saving current model to {}'.format(save_path))
            else:
                evals_since_best += 1
                if param.patience > 0 and evals_since_best >= param.patience:
                    stop_reason = 'early_stop'
                    logging.info('Early stopping: no RC@5 improvement for {} consecutive '
                                 'evaluations (patience={}).'.format(evals_since_best, param.patience))
                    break

    logging.info('Recommender training finished ({}) after {} epochs, best epoch {} with '
                 'validation RC5 = {:.4f}, total time {:.1f} min.'.format(
                     stop_reason, epoch_num, best_epoch, best_score, (time() - time_start) / 60))

    if best_epoch > 0:
        checkpoint = torch.load(save_path, map_location=param.device)
        module.load_state_dict(checkpoint['model_state_dict'])
        [rc_5, rc_20, mrr_5, mrr_20] = model_evaluation(
            module=module, batches_eval=test_batches, eval_length=len(test_data), param=param)
        log_eval_box('Final test evaluation (best epoch {})'.format(best_epoch),
                     rc_5, rc_20, mrr_5, mrr_20)
        logging.info('Final test performance of the selected checkpoint: RC5 = {:.4f}, '
                     'RC20 = {:.4f}, MRR5 = {:.4f}, MRR20 = {:.4f}.'.format(
                         rc_5, rc_20, mrr_5, mrr_20))
    else:
        logging.warning('No evaluation was performed, no checkpoint to test.')

    logging.info('All process finished.')


if __name__ == '__main__':
    main()
